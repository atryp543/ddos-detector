import type { DetectionFunction, RawFlowData } from "./types"

/**
 * Detects DDoS based on SYN Ratio.
 * If any flow in the batch has a SYN Flag Count to Total Fwd Packets ratio
 * above the threshold, the entire batch is flagged.
 */
export const detectSynRatio: DetectionFunction = (flowBatch: RawFlowData[]): boolean => {
    const threshold = 0.6
    for (const flow of flowBatch) {
        if (flow["Total Fwd Packets"] === 0) continue
        const synRatio = flow["SYN Flag Count"] / flow["Total Fwd Packets"]
        if (synRatio > threshold) {
            return true
        }
    }
    return false
}
