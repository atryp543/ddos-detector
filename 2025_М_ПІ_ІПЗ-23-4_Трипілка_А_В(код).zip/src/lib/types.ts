export const DETECTION_METHODS = [
  "None",
  "AutoEncoder+LSTM",
  "Deep RL",
  "Algorithmic - SYN Ratio",
  "Algorithmic - Unidirectionality",
  "Algorithmic - IAT Regularity",
] as const

export type DetectionMethod = (typeof DETECTION_METHODS)[number]

export interface NetworkFlow {
  id: string
  timestamp: string
  sourceIp: string
  destinationIp: string
  label: "NORMAL" | "SUSPICIOUS"
  markedBy?: DetectionMethod

  "Flow ID"?: string
  "Src Port"?: number
  "Dst Port"?: number
  Protocol?: number

  "Flow Duration": number
  "Total Fwd Packets": number
  "Total Backward Packets": number
  "Fwd Packets Length Total": number
  "Bwd Packets Length Total": number

  "Fwd Packet Length Max"?: number
  "Fwd Packet Length Min"?: number
  "Fwd Packet Length Mean"?: number
  "Fwd Packet Length Std"?: number
  "Bwd Packet Length Max"?: number
  "Bwd Packet Length Min"?: number
  "Bwd Packet Length Mean"?: number
  "Bwd Packet Length Std"?: number

  "Flow Bytes/s"?: number
  "Flow Packets/s": number
  "Fwd Packets/s": number
  "Bwd Packets/s": number

  "Flow IAT Mean": number
  "Flow IAT Std": number
  "Flow IAT Max": number
  "Flow IAT Min": number
  "Fwd IAT Total": number
  "Fwd IAT Mean": number
  "Fwd IAT Std": number
  "Fwd IAT Max": number
  "Fwd IAT Min": number
  "Bwd IAT Total": number
  "Bwd IAT Mean": number
  "Bwd IAT Std": number
  "Bwd IAT Max": number
  "Bwd IAT Min": number

  "Fwd PSH Flags": number
  "Bwd PSH Flags": number
  "Fwd URG Flags": number
  "Bwd URG Flags": number
  "Fwd Header Length": number
  "Bwd Header Length": number

  "Packet Length Min"?: number
  "Packet Length Max"?: number
  "Packet Length Mean"?: number
  "Packet Length Std"?: number
  "Packet Length Variance"?: number

  "FIN Flag Count"?: number
  "SYN Flag Count": number
  "RST Flag Count": number
  "PSH Flag Count"?: number
  "ACK Flag Count": number
  "URG Flag Count"?: number
  "CWR Flag Count"?: number
  "ECE Flag Count": number

  "Down/Up Ratio": number
  "Average Packet Size"?: number
  "Fwd Segment Size Avg"?: number
  "Bwd Segment Size Avg"?: number

  "Fwd Avg Bytes/Bulk": number
  "Fwd Avg Packets/Bulk": number
  "Fwd Avg Bulk Rate": number
  "Bwd Avg Bytes/Bulk": number
  "Bwd Avg Packets/Bulk": number
  "Bwd Avg Bulk Rate": number

  "Subflow Fwd Packets": number
  "Subflow Fwd Bytes": number
  "Subflow Bwd Packets": number
  "Subflow Bwd Bytes": number

  "Init Fwd Win Bytes": number
  "Init Bwd Win Bytes": number
  "Fwd Act Data Pkts"?: number
  "Fwd Seg Size Min"?: number

  "Active Mean": number
  "Active Std": number
  "Active Max": number
  "Active Min": number
  "Idle Mean": number
  "Idle Std": number
  "Idle Max": number
  "Idle Min": number
}

export interface MaliciousPercentagePoint {
  timestamp: number
  percentage: number
}

export interface DashboardStatusResponse {
  isUnderAttack: boolean
  currentSuspiciousPercentage: number
  suspiciousPercentageHistory: MaliciousPercentagePoint[]
  logs: NetworkFlow[]
  activeDetectionMethod: DetectionMethod
  totalLogsInWindow: number
  suspiciousLogsInWindow: number
}

export type RawFlowData = Omit<NetworkFlow, "id" | "label" | "timestamp" | "markedBy">

export interface IngestRequestBody {
  logs: RawFlowData[]
}

export interface MLServiceFlowSchema {
  flow_duration: number
  total_fwd_packets: number
  total_bwd_packets: number
  fwd_packet_length_total: number
  bwd_packet_length_total: number
  flow_packets_s: number
  flow_iat_mean: number
  flow_iat_std: number
  flow_iat_max: number
  flow_iat_min: number
  fwd_iat_total: number
  fwd_iat_mean: number
  fwd_iat_std: number
  fwd_iat_max: number
  fwd_iat_min: number
  bwd_iat_total: number
  bwd_iat_mean: number
  bwd_iat_std: number
  bwd_iat_max: number
  bwd_iat_min: number
  fwd_psh_flags: number
  bwd_psh_flags: number
  fwd_urg_flags: number
  bwd_urg_flags: number
  fwd_header_length: number
  bwd_header_length: number
  fwd_packet_s: number
  bwd_packet_s: number
  syn_flag_count: number
  rst_flag_count: number
  ack_flag_count: number
  ece_flag_count: number
  down_up_ratio: number
  fwd_avg_bytes_bulk: number
  fwd_avg_packets_bulk: number
  fwd_avg_bulk_rate: number
  bwd_avg_bytes_bulk: number
  bwd_avg_packets_bulk: number
  bwd_avg_bulk_rate: number
  subflow_fwd_packets: number
  subflow_fwd_bytes: number
  subflow_bwd_packets: number
  subflow_bwd_bytes: number
  init_fwd_win_bytes: number
  init_bwd_win_bytes: number
  active_mean: number
  active_std: number
  active_max: number
  active_min: number
  idle_mean: number
  idle_std: number
  idle_max: number
  idle_min: number
}

export interface MLServiceRequestBody {
  requests: MLServiceFlowSchema[]
}
