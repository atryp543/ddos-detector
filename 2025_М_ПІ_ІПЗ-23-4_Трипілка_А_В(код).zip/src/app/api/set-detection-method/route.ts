import { NextResponse, type NextRequest } from "next/server"
import { setDetectionMethod } from "@/lib/redis-service"
import { DETECTION_METHODS, type DetectionMethod } from "@/lib/types"

export async function POST(request: NextRequest) {
  try {
    const { method } = (await request.json()) as { method: DetectionMethod }

    if (!DETECTION_METHODS.includes(method)) {
      return NextResponse.json({ error: "Invalid detection method" }, { status: 400 })
    }

    await setDetectionMethod(method)
    console.log(`Detection method set to: ${method}.`)
    return NextResponse.json({ success: true, method })
  } catch (error) {
    console.error("Error setting detection method:", error)
    const errorMessage = error instanceof Error ? error.message : "Unknown server error"
    return NextResponse.json({ error: "Internal server error", details: errorMessage }, { status: 500 })
  }
}
