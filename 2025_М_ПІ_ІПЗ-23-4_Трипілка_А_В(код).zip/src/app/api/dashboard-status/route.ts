import { NextResponse } from "next/server"
import { getDetectionMethod, getRecentLogIds, getLogsByIds, getRecentBatchDdosStatuses } from "@/lib/redis-service"
import type { DashboardStatusResponse, NetworkFlow, MaliciousPercentagePoint } from "@/lib/types"
import { MAX_RECENT_BATCHES_TRACKED } from "@/lib/redis-keys"

const MAX_LOGS_TO_RETURN_UI = 50
const DATA_WINDOW_MS = 5 * 60 * 1000 // 5 minutes for flow stats and chart
const CHART_INTERVALS = 60
const ATTACK_BATCH_THRESHOLD_PERCENTAGE = 20 // System is "under attack" if >= this % of recent batches were DDoS

export async function GET() {
  try {
    const now = Date.now()
    const activeDetectionMethod = await getDetectionMethod()

    // --- Flow-based stats (for chart and overall suspicious flow percentage badge) ---
    const allLogIdsInDataWindow = await getRecentLogIds(now - DATA_WINDOW_MS, now, 10000, 0, false)
    const allFlowsInDataWindow: NetworkFlow[] = await getLogsByIds(allLogIdsInDataWindow)

    const totalLogsInWindow = allFlowsInDataWindow.length
    const suspiciousLogsInWindow = allFlowsInDataWindow.filter((flow) => flow.label === "SUSPICIOUS").length
    // This percentage is of *individual flows* in the last 5 minutes, for the UI badge
    const currentSuspiciousFlowPercentage =
        totalLogsInWindow > 0 ? (suspiciousLogsInWindow / totalLogsInWindow) * 100 : 0

    // Prepare logs for initial UI display
    const sortedFlowsForUi = [...allFlowsInDataWindow].sort(
        (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime(),
    )
    const flowsForUi: NetworkFlow[] = sortedFlowsForUi.slice(0, MAX_LOGS_TO_RETURN_UI)

    // Chart data (based on flow percentages over intervals)
    const suspiciousPercentageHistory: MaliciousPercentagePoint[] = []
    const intervalDuration = DATA_WINDOW_MS / CHART_INTERVALS
    for (let i = 0; i < CHART_INTERVALS; i++) {
      const intervalEnd = now - i * intervalDuration
      const intervalStart = intervalEnd - intervalDuration
      const flowsInInterval = allFlowsInDataWindow.filter((flow) => {
        const t = new Date(flow.timestamp).getTime()
        return t >= intervalStart && t < intervalEnd
      })

      let percentageInInterval = 0
      if (flowsInInterval.length > 0) {
        const suspiciousFlowsInInterval = flowsInInterval.filter(
            (flow) =>
                flow.label === "SUSPICIOUS" &&
                (activeDetectionMethod === "None" || flow.markedBy === activeDetectionMethod),
        )
        percentageInInterval = (suspiciousFlowsInInterval.length / flowsInInterval.length) * 100
      }
      suspiciousPercentageHistory.push({ timestamp: intervalEnd, percentage: percentageInInterval })
    }
    suspiciousPercentageHistory.reverse()

    // --- Batch-based "System Under Attack" status ---
    const recentBatchStatuses = await getRecentBatchDdosStatuses()
    let isUnderAttack = false
    if (recentBatchStatuses.length > 0) {
      const ddosBatchCount = recentBatchStatuses.filter(Boolean).length
      const relevantBatchCount = Math.min(recentBatchStatuses.length, MAX_RECENT_BATCHES_TRACKED)
      const percentageDdosBatches = relevantBatchCount > 0 ? (ddosBatchCount / relevantBatchCount) * 100 : 0

      // System is under attack if batch threshold is met AND there are currently suspicious flows
      if (percentageDdosBatches >= ATTACK_BATCH_THRESHOLD_PERCENTAGE && currentSuspiciousFlowPercentage > 0) {
        isUnderAttack = true
      }
    }

    const response: DashboardStatusResponse = {
      isUnderAttack, // Driven by batch statuses
      currentSuspiciousPercentage: currentSuspiciousFlowPercentage, // Flow-based percentage for the badge
      suspiciousPercentageHistory,
      logs: flowsForUi,
      activeDetectionMethod,
      totalLogsInWindow,
      suspiciousLogsInWindow,
    }
    return NextResponse.json(response)
  } catch (error) {
    console.error("[/api/dashboard-status] CRITICAL ERROR:", error)
    const errorMessage = error instanceof Error ? error.message : "Unknown server error"
    return NextResponse.json(
        {
          error: "Internal server error in dashboard status API.",
          details: process.env.NODE_ENV === "development" ? errorMessage : undefined,
        },
        { status: 500 },
    )
  }
}
