import { NextResponse } from "next/server"

export async function GET() {
    try {
        // In a more complex scenario, you might check database connections,
        // external service availability, etc. here.
        // For now, if the API route itself is reachable and executes,
        // we consider the basic API functionality "healthy".

        return NextResponse.json(
            {
                status: "ok",
                timestamp: new Date().toISOString(),
                message: "Network Flow Monitor API is running.",
            },
            { status: 200 },
        )
    } catch (error) {
        // This catch block would handle unexpected errors within the health check logic itself.
        console.error("[/api/health] Critical error in health check:", error)
        const errorMessage = error instanceof Error ? error.message : "Unknown server error"
        return NextResponse.json(
            {
                status: "error",
                timestamp: new Date().toISOString(),
                message: "Health check endpoint encountered an internal error.",
                details: process.env.NODE_ENV === "development" ? errorMessage : undefined,
            },
            { status: 500 },
        )
    }
}
