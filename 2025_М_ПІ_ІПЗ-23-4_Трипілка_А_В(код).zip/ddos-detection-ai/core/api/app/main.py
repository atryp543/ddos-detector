from fastapi import FastAPI

from core.api.app.routers import ddos_detection_router

app = FastAPI(root_path="/api")

app.include_router(ddos_detection_router)