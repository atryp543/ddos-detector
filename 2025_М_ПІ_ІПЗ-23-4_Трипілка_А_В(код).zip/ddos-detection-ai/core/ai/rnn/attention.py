from torch import nn
import torch

class Attention(nn.Module):
    def __init__(self, hidden_dim: int):
        super().__init__()
        self.score_layer = nn.Linear(hidden_dim, 1, bias=False)

    def forward(self, lstm_outputs: torch.Tensor, lengths: torch.Tensor):
        scores = self.score_layer(lstm_outputs).squeeze(-1)
        lstm_outputs = lstm_outputs
        max_len = lstm_outputs.size(1)
        mask = (
            torch.arange(max_len, device=lengths.device)
            .unsqueeze(0)
            .expand(len(lengths), max_len)
            >= lengths.unsqueeze(1)
        )
        scores = scores.masked_fill(mask, float('-inf'))

        attn_weights = torch.softmax(scores, dim=1)

        context = torch.bmm(attn_weights.unsqueeze(1), lstm_outputs).squeeze(1)
        return context, attn_weights