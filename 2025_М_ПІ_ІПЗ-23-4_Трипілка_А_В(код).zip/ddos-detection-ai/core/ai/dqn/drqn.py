import torch.nn as nn
import torch

class DRQN(nn.Module):
    def __init__(self, input_dim, hidden_dim, action_dim):
        super(DRQN, self).__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, action_dim)
        self.hidden_dim = hidden_dim

    def forward(self, x, hidden):
        out, hidden = self.lstm(x, hidden)
        q_values = self.fc(out[:, -1, :])
        return q_values, hidden

    def init_hidden(self, batch_size, device):
        h0 = torch.zeros(1, batch_size, self.hidden_dim, device=device)
        c0 = torch.zeros(1, batch_size, self.hidden_dim, device=device)
        return h0, c0
